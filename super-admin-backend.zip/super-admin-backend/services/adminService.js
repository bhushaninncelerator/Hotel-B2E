const Admin = require('../models/Admin');
const bcrypt = require('bcryptjs');

const createAdmin = async ({ companyName, email, password }) => {
  const admin = new Admin({ companyName, email, password });
  await admin.save();
  return admin;
};

module.exports = {
  createAdmin,
};