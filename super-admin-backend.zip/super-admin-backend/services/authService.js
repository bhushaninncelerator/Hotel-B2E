const SuperAdmin = require('../models/SuperAdmin');
const bcrypt = require('bcryptjs');

const registerSuperAdmin = async ({ email, password }) => {
  const superAdmin = new SuperAdmin({ email, password });
  await superAdmin.save();
  return superAdmin;
};

const loginSuperAdmin = async ({ email, password }) => {
  const superAdmin = await SuperAdmin.findOne({ email });
  if (!superAdmin) {
    throw new Error('Invalid login credentials');
  }

  const isMatch = await superAdmin.comparePassword(password);
  if (!isMatch) {
    throw new Error('Invalid login credentials');
  }

  return superAdmin;
};

module.exports = {
  registerSuperAdmin,
  loginSuperAdmin,
};