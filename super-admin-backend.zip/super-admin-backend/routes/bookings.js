const express = require("express");
const Order = require("../models/Order");
const router = express.Router();

// Route to save hotel booking details
router.post("/save-order", async (req, res) => {
  try {
    const bookingData = req.body; // Get data from RezLive API response

    // Create and save the order in MongoDB
    const newOrder = new Order({
      orderId: bookingData.order_id,
      userId: bookingData.user_id, // Ensure user info is included
      hotelName: bookingData.hotel_name,
      checkIn: new Date(bookingData.check_in),
      checkOut: new Date(bookingData.check_out),
      totalPrice: bookingData.total_price,
      guests: bookingData.guests,
      bookingStatus: "Confirmed",
    });

    await newOrder.save();

    res.status(201).json({ message: "Order saved successfully", order: newOrder });
  } catch (error) {
    res.status(500).json({ error: "Failed to save order", details: error.message });
  }
});

module.exports = router;
