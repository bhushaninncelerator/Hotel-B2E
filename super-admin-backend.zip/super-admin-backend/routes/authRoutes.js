const fp = require('fastify-plugin');
const SuperAdmin = require('../models/SuperAdmin');
const Admin = require('../models/Admin');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
const crypto = require('crypto');

// Create a Nodemailer transporter (replace with your email service credentials)
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'your-email@gmail.com', // Replace with your email
    pass: 'your-email-password', // Replace with your email password
  },
});

module.exports = fp(async (fastify, opts) => {
  // Super Admin Login
  fastify.post('/login', async (request, reply) => {
    const { email, password } = request.body;

    // Validate request payload
    if (!email || !password) {
      return reply.status(400).send({ message: 'Email and password are required' });
    }

    try {
      // Find Super Admin by email
      const superAdmin = await SuperAdmin.findOne({ email });
      if (!superAdmin) {
        return reply.status(400).send({ message: 'Invalid email or password' });
      }

      // Compare password
      const isMatch = await superAdmin.comparePassword(password);
      if (!isMatch) {
        return reply.status(400).send({ message: 'Invalid email or password' });
      }

      // Generate JWT token
      const token = fastify.jwt.sign({ id: superAdmin._id, role: 'superadmin' });
      reply.send({ token });
    } catch (error) {
      reply.status(500).send({ message: 'Internal server error' });
    }
  });

  // Admin Login
  fastify.post('/admin/login', async (request, reply) => {
    const { email, password } = request.body;

    // Validate request payload
    if (!email || !password) {
      return reply.status(400).send({ message: 'Email and password are required' });
    }

    try {
      // Find Admin by email
      const admin = await Admin.findOne({ email });
      if (!admin) {
        return reply.status(400).send({ message: 'Invalid email or password' });
      }

      // Compare password
      const isMatch = await admin.comparePassword(password);
      if (!isMatch) {
        return reply.status(400).send({ message: 'Invalid email or password' });
      }

      // Generate JWT token
      const token = fastify.jwt.sign({ id: admin._id, role: 'admin' });
      reply.send({ token });
    } catch (error) {
      reply.status(500).send({ message: 'Internal server error' });
    }
  });

  // Forgot Password - Super Admin
  fastify.post('/super-admin/forgot-password', async (request, reply) => {
    const { email } = request.body;

    try {
      const superAdmin = await SuperAdmin.findOne({ email });
      if (!superAdmin) {
        return reply.status(404).send({ message: 'Super Admin not found' });
      }

      // Generate a reset token
      const resetToken = crypto.randomBytes(20).toString('hex');
      superAdmin.resetPasswordToken = resetToken;
      superAdmin.resetPasswordExpires = Date.now() + 3600000; // 1 hour
      await superAdmin.save();

      // Send reset email
      const resetUrl = `http://localhost:5173/reset-password?token=${resetToken}`;
      const mailOptions = {
        to: superAdmin.email,
        from: 'your-email@gmail.com',
        subject: 'Password Reset',
        text: `You are receiving this because you (or someone else) have requested the reset of the password for your account.\n\n
          Please click on the following link, or paste it into your browser to complete the process:\n\n
          ${resetUrl}\n\n
          If you did not request this, please ignore this email and your password will remain unchanged.\n`,
      };

      await transporter.sendMail(mailOptions);
      reply.send({ message: 'Password reset email sent' });
    } catch (error) {
      console.error('Error sending reset email:', error);
      reply.status(500).send({ message: 'Internal server error' });
    }
  });

  // Forgot Password - Admin
  fastify.post('/admin/forgot-password', async (request, reply) => {
    const { email } = request.body;

    try {
      const admin = await Admin.findOne({ email });
      if (!admin) {
        return reply.status(404).send({ message: 'Admin not found' });
      }

      // Generate a reset token
      const resetToken = crypto.randomBytes(20).toString('hex');
      admin.resetPasswordToken = resetToken;
      admin.resetPasswordExpires = Date.now() + 3600000; // 1 hour
      await admin.save();

      // Send reset email
      const resetUrl = `http://localhost:5173/reset-password?token=${resetToken}`;
      const mailOptions = {
        to: admin.email,
        from: 'your-email@gmail.com',
        subject: 'Password Reset',
        text: `You are receiving this because you (or someone else) have requested the reset of the password for your account.\n\n
          Please click on the following link, or paste it into your browser to complete the process:\n\n
          ${resetUrl}\n\n
          If you did not request this, please ignore this email and your password will remain unchanged.\n`,
      };

      await transporter.sendMail(mailOptions);
      reply.send({ message: 'Password reset email sent' });
    } catch (error) {
      console.error('Error sending reset email:', error);
      reply.status(500).send({ message: 'Internal server error' });
    }
  });

  // Reset Password - Super Admin
  fastify.post('/super-admin/reset-password', async (request, reply) => {
    const { token, password } = request.body;

    try {
      const superAdmin = await SuperAdmin.findOne({
        resetPasswordToken: token,
        resetPasswordExpires: { $gt: Date.now() },
      });

      if (!superAdmin) {
        return reply.status(400).send({ message: 'Invalid or expired token' });
      }

      // Hash the new password
      superAdmin.password = password;
      superAdmin.resetPasswordToken = undefined;
      superAdmin.resetPasswordExpires = undefined;
      await superAdmin.save();

      reply.send({ message: 'Password reset successfully' });
    } catch (error) {
      console.error('Error resetting password:', error);
      reply.status(500).send({ message: 'Internal server error' });
    }
  });

  // Reset Password - Admin
  fastify.post('/admin/reset-password', async (request, reply) => {
    const { token, password } = request.body;

    try {
      const admin = await Admin.findOne({
        resetPasswordToken: token,
        resetPasswordExpires: { $gt: Date.now() },
      });

      if (!admin) {
        return reply.status(400).send({ message: 'Invalid or expired token' });
      }

      // Hash the new password
      admin.password = password;
      admin.resetPasswordToken = undefined;
      admin.resetPasswordExpires = undefined;
      await admin.save();

      reply.send({ message: 'Password reset successfully' });
    } catch (error) {
      console.error('Error resetting password:', error);
      reply.status(500).send({ message: 'Internal server error' });
    }
  });
});