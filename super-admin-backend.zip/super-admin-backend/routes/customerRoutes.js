const fp = require('fastify-plugin');
const Customer = require('../models/Customer');

module.exports = fp(async (fastify, opts) => {
  // Customer Register
  fastify.post('/customer/register', async (request, reply) => {
    const { name, email, password } = request.body;

    // Validate request payload
    if (!name || !email || !password) {
      return reply.status(400).send({ message: 'Name, email, and password are required' });
    }

    try {
      const customer = new Customer({ name, email, password });
      await customer.save();
      reply.send({ message: 'Customer registered successfully', customer });
    } catch (error) {
      console.error('Error registering customer:', error);
      if (error.code === 11000) { // Duplicate key error (e.g., duplicate email)
        return reply.status(400).send({ message: 'Email already exists' });
      }
      reply.status(500).send({ message: 'Internal server error' });
    }
  });

  // Customer Login
  fastify.post('/customer/login', async (request, reply) => {
    const { email, password } = request.body;

    // Validate request payload
    if (!email || !password) {
      return reply.status(400).send({ message: 'Email and password are required' });
    }

    try {
      const customer = await Customer.findOne({ email });
      if (!customer) {
        return reply.status(400).send({ message: 'Invalid email or password' });
      }

      const isMatch = await customer.comparePassword(password);
      if (!isMatch) {
        return reply.status(400).send({ message: 'Invalid email or password' });
      }

      const token = fastify.jwt.sign({ id: customer._id, role: 'customer' });
      reply.send({ token });
    } catch (error) {
      console.error('Error logging in customer:', error);
      reply.status(500).send({ message: 'Internal server error' });
    }
  });

  // Fetch all Customers (Admin and Super Admin only)
  fastify.get('/customers', { onRequest: [fastify.authenticate] }, async (request, reply) => {
    // Check if the authenticated user is an Admin or Super Admin
    if (request.user.role !== 'admin' && request.user.role !== 'superadmin') {
      return reply.status(403).send({ message: 'Only Admin or Super Admin can view customers' });
    }

    try {
      const customers = await Customer.find({}, { password: 0 }); // Exclude passwords
      reply.send({ customers });
    } catch (error) {
      console.error('Error fetching customers:', error);
      reply.status(500).send({ message: 'Internal server error' });
    }
  });

  // Ban/Unban Customer (Admin and Super Admin only)
  fastify.patch('/customer/:id/ban', { onRequest: [fastify.authenticate] }, async (request, reply) => {
    const { id } = request.params;
    const { banned } = request.body;

    // Check if the authenticated user is an Admin or Super Admin
    if (request.user.role !== 'admin' && request.user.role !== 'superadmin') {
      return reply.status(403).send({ message: 'Only Admin or Super Admin can ban/unban customers' });
    }

    try {
      const customer = await Customer.findByIdAndUpdate(id, { banned }, { new: true });
      if (!customer) {
        return reply.status(404).send({ message: 'Customer not found' });
      }
      reply.send({ message: `Customer ${banned ? 'banned' : 'unbanned'} successfully`, customer });
    } catch (error) {
      console.error('Error banning/unbanning customer:', error);
      reply.status(500).send({ message: 'Internal server error' });
    }
  });

  // Delete Customer (Admin and Super Admin only)
  fastify.delete('/customer/:id', { onRequest: [fastify.authenticate] }, async (request, reply) => {
    const { id } = request.params;

    // Check if the authenticated user is an Admin or Super Admin
    if (request.user.role !== 'admin' && request.user.role !== 'superadmin') {
      return reply.status(403).send({ message: 'Only Admin or Super Admin can delete customers' });
    }

    try {
      const customer = await Customer.findByIdAndDelete(id);
      if (!customer) {
        return reply.status(404).send({ message: 'Customer not found' });
      }
      reply.send({ message: 'Customer deleted successfully' });
    } catch (error) {
      console.error('Error deleting customer:', error);
      reply.status(500).send({ message: 'Internal server error' });
    }
  });
});