const fp = require('fastify-plugin');
const Admin = require('../models/Admin');

module.exports = fp(async (fastify, opts) => {
  // Create Admin (Super Admin only)
  fastify.post('/admin/create', { onRequest: [fastify.authenticate] }, async (request, reply) => {
    const { companyName, email, password } = request.body;

    // Check if the authenticated user is a Super Admin
    if (request.user.role !== 'superadmin') {
      return reply.status(403).send({ message: 'Only Super Admin can create Admin accounts' });
    }

    try {
      const admin = new Admin({ companyName, email, password });
      await admin.save();
      reply.send({ message: 'Admin created successfully', admin });
    } catch (error) {
      console.error('Error creating admin:', error);
      reply.status(400).send({ message: error.message });
    }
  });

  // Fetch all Admins (Super Admin only)
  fastify.get('/admins', { onRequest: [fastify.authenticate] }, async (request, reply) => {
    // Check if the authenticated user is a Super Admin
    if (request.user.role !== 'superadmin') {
      return reply.status(403).send({ message: 'Only Super Admin can view Admin accounts' });
    }

    try {
      const admins = await Admin.find({}, { password: 0 }); // Exclude passwords
      reply.send({ admins });
    } catch (error) {
      console.error('Error fetching admins:', error);
      reply.status(500).send({ message: 'Internal server error' });
    }
  });

  // Ban/Unban Admin (Super Admin only)
  fastify.patch('/admin/:id/ban', { onRequest: [fastify.authenticate] }, async (request, reply) => {
    const { id } = request.params;
    const { banned } = request.body;

    // Check if the authenticated user is a Super Admin
    if (request.user.role !== 'superadmin') {
      return reply.status(403).send({ message: 'Only Super Admin can ban/unban Admin accounts' });
    }

    try {
      const admin = await Admin.findByIdAndUpdate(id, { banned }, { new: true });
      if (!admin) {
        return reply.status(404).send({ message: 'Admin not found' });
      }
      reply.send({ message: `Admin ${banned ? 'banned' : 'unbanned'} successfully`, admin });
    } catch (error) {
      console.error('Error banning/unbanning admin:', error);
      reply.status(500).send({ message: 'Internal server error' });
    }
  });

  // Delete Admin (Super Admin only)
  fastify.delete('/admin/:id', { onRequest: [fastify.authenticate] }, async (request, reply) => {
    const { id } = request.params;

    // Check if the authenticated user is a Super Admin
    if (request.user.role !== 'superadmin') {
      return reply.status(403).send({ message: 'Only Super Admin can delete Admin accounts' });
    }

    try {
      const admin = await Admin.findByIdAndDelete(id);
      if (!admin) {
        return reply.status(404).send({ message: 'Admin not found' });
      }
      reply.send({ message: 'Admin deleted successfully' });
    } catch (error) {
      console.error('Error deleting admin:', error);
      reply.status(500).send({ message: 'Internal server error' });
    }
  });
});